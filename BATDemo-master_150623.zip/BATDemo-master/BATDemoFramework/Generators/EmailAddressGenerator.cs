namespace BATDemoFramework.Generators
{
    public class EmailAddressGenerator
    {
        public static string Generate()
        {
            return "random@random.com";
        }
    }
}